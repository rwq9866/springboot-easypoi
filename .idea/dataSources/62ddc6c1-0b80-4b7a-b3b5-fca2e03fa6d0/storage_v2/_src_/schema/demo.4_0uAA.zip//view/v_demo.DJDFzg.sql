CREATE VIEW v_demo AS
  SELECT sum(`demo`.`demo`.`sal`) AS `sum(sal)`
  FROM `demo`.`demo`;

